import Vue from 'vue'
import VueHighlightJs from "vue-hljs";
import "highlight.js/styles/atom-one-dark.css";

Vue.use(VueHighlightJs)
