import Vue from 'vue'
import Tooltip from 'lefuturiste-vue-directive-tooltip';
import 'lefuturiste-vue-directive-tooltip/dist/vueDirectiveTooltip.css';

Vue.use(Tooltip);
