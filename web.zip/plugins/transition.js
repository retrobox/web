import Vue from 'vue'
import Transitions from 'vue2-transitions'

Vue.use(Transitions)
