const routes = require('./routes.json')

module.exports = async function getAppRoutes() {
    return routes
}
