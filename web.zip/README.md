# Retrobox Website

> The retrobox website made with nuxt.js

[![CircleCI](https://circleci.com/gh/retrobox/web.svg?style=svg)](https://circleci.com/gh/retrobox/web)

## Preview

![alt text](https://static.retrobox.tech/img/firefox_h6GDEeX8FJ.png)

## Build Setup

``` bash
# install dependencies
$ yarn install

# serve with hot reload at localhost:3000
$ yarn run dev

# build for production and launch server
$ yarn run build
$ yarn start

# generate static project
$ yarn run generate
```

For detailed explanation on how things work, checkout [Nuxt.js docs](https://nuxtjs.org).
