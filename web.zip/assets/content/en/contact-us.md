<h2 class="dividing">By email</h2>

By sending an email to: [contact@retrobox.tech](mailto:contact@retrobox.tech)

<h2 class="dividing">By discord</h2>

By joining our discord guild with: [this pretty discord link](https://discord.gg/TzNNQnP)

<h2 class="dividing">By mail</h2>

Thingmill

1 chemin de badoire

Heloup, 61250, France

<h2 class="dividing">By a call</h2>

`+33 7 69 99 75 49`
