### 1\. Dépendances utilisées pour l'overlay RetroBox sur RetroPie.

### 2\. Dépendances utilisées pour l'application desktop.

### 3\. Dépendances utilisées pour l'application mobile.

### 4\. Dépendances utilisées pour les services web.

### 5\. Abandonware préinstallés.
