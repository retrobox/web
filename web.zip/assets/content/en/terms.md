### Welcome to https://retrobox.tech

This work is under the Creative Commons BY-NC-SA license, that is to say that you do not have the right to redistribute the product without authorization, to make modifications for commercial purposes or to attribute the project to you.

In addition, we do not provide games with the console for legality. RetroPie is not sold pre-installed because the license does not authorize it, it is only installed from the application **after** the purchase. <br /><br />

https://retrobox.tech is published by Thingmill (https://thingmill.fr)
