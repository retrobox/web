<h2 class="dividing">Par email</h2>

En nous envoyant un email à: [contact@retrobox.tech](mailto:contact@retrobox.tech)

<h2 class="dividing">Par Discord</h2>

En rejoignant notre serveur discord par : [ce lien](https://discord.gg/TzNNQnP)

<h2 class="dividing">Avec Laposte</h2>

Thingmill

1 chemin de badoire

Heloup, 61250, France

<h2 class="dividing">Par téléphone</h2>

`+33 7 69 99 75 49`
