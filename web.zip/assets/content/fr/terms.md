### Bienvenue sur https://retrobox.tech

Ce travail est sous la license Creative Commons BY-NC-SA, c'est à dire que vous n'avez pas le droit de redistribuer le produit sans autorisation, d'effectuer des modifications a titre commercial ou de vous attribuer le projet.

Par ailleurs nous ne fournissons pas les jeux avec la console pour une question de légalité. RetroPie n'est pas vendu pré-installé car la license ne l'autorise pas, il est seulement installé a partir de l'application **après** l'achat.<br />
<br />
https://retrobox.tech est édité par Thingmill (https://thingmill.fr)
