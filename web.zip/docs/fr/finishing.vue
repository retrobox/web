<template>
  <div>
    <DocsHeading label="La finition" />
    <p>
      C'est encore vide ici... Mais ne t'inquiète pas cela va se remplir très vite.
    </p>
  </div>
</template>
<script>
  import DocsHeading from "~/components/DocsHeading"
  import DocsImage from "~/components/DocsImage"
  export default {
    name: 'FrenchFinishing',
    components: {DocsImage, DocsHeading}
  }
</script>
