<template>
  <div>
    <DocsHeading label="Le schéma de la console" />

    <p>Travail en cours ici aussi :)</p>
  </div>
</template>
<script>
  import DocsHeading from "~/components/DocsHeading"
  import DocsImage from "~/components/DocsImage"
  export default {
    components: {DocsImage, DocsHeading}
  }
</script>
