<template>
  <div>
    <DocsHeading label="Explication de l'infrastructure de RetroBox" />

    <p>Travail en cours ici aussi :)</p>
  </div>
</template>
<script>
  import DocsHeading from "~/components/DocsHeading"
  import DocsImage from "~/components/DocsImage"
  export default {
    components: {DocsImage, DocsHeading}
  }
</script>
