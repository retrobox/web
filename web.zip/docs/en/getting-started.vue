<template>
  <div>
    Getting started page in english
  </div>
</template>

<script>
  export default {
    name: 'EnglishGettingStarted'
  }
</script>
