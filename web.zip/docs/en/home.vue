<template>
  <div>
    The english documentation is in work in progress please refer you to the french documentation
  </div>
</template>

<script>
  export default {
    name: 'EnglishHome'
  }
</script>
